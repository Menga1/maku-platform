"""
MAKU - Solar (Desert) page
UI only. All calculations come from risk_engine.calculate_solar_albedo_heat_risk
(Mathematical Isolation rule - no formulas live in this file).
"""

import streamlit as st
from risk_engine import calculate_solar_albedo_heat_risk
from ai_advisor import get_controls, generate_narrative
from i18n import t, language_selector

st.set_page_config(page_title="MAKU - Solar (Desert)", page_icon="☀️", layout="wide")

lang = language_selector(st)

st.sidebar.title(t("app_title", lang))
st.sidebar.caption(t("app_tagline", lang))
st.sidebar.markdown("---")
st.sidebar.subheader(t("ai_layer_header", lang))
api_key = st.sidebar.text_input(
    t("api_key_label", lang), type="password", help=t("api_key_help", lang),
)

st.title(t("solar_header", lang))
st.caption(t("solar_caption", lang))
st.caption(t("env_inputs_note", lang))

col_inputs, col_results = st.columns([1, 2])

SURFACE_TYPES = ["pure_desert_sand", "silicon_pv_panels", "hybrid_assembly_zone"]

with col_inputs:
    st.header(t("solar_env_data_header", lang))
    temp = st.slider(t("solar_temp_label", lang), 20.0, 55.0, 38.0)
    ghi = st.number_input(t("solar_ghi_label", lang), 0, 1200, 850)
    uv = st.slider(t("solar_uv_label", lang), 0, 15, 9)
    surface = st.selectbox(
        t("solar_surface_label", lang),
        SURFACE_TYPES,
        format_func=lambda v: t(f"surf_{v}", lang),
    )

# Live calculation via the MAKU risk engine (Mathematical Isolation - no math here)
result = calculate_solar_albedo_heat_risk(ghi, uv, temp, surface)
controls = get_controls(result)

with col_results:
    st.header(t("solar_realtime_header", lang))

    c1, c2, c3 = st.columns(3)
    c1.metric(
        t("perceived_temp_label", lang),
        f"{result['perceived_temp']} °C",
        f"+{result['thermal_amplification']}°C {t('albedo_delta_label', lang)}",
    )
    c2.metric(t("risk_level_label", lang), result["risk_level"])
    c3.metric(t("shift_rotation_label", lang), result["max_shift_duration"])

    if result["risk_level"] == "CRITICAL":
        st.error(f"{t('solar_critical_alert', lang)} {result['max_shift_duration']}.")
    elif result["risk_level"] == "HIGH":
        st.warning(f"{t('solar_high_alert', lang)} {result['max_shift_duration']}.")
    else:
        st.success(t("solar_standard_ok", lang))

    with st.expander(t("drivers_label", lang)):
        st.json(result["drivers"])

    st.subheader(t("controls_label", lang))
    for c in controls:
        st.markdown(f"- {c}")

    st.subheader(t("briefing_label", lang))
    st.info(generate_narrative(result, controls, api_key, lang))
