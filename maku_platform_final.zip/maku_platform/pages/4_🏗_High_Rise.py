"""
MAKU - High-Rise (Vertical Urban) page
UI only. All calculations come from risk_engine.calculate_high_rise_kinetic_risk
(Mathematical Isolation rule - no formulas live in this file).
"""

import streamlit as st
from risk_engine import calculate_high_rise_kinetic_risk
from ai_advisor import get_controls, generate_narrative
from i18n import t, language_selector

st.set_page_config(page_title="MAKU - High-Rise", page_icon="🏗️", layout="wide")

lang = language_selector(st)

st.sidebar.title(t("app_title", lang))
st.sidebar.caption(t("app_tagline", lang))
st.sidebar.markdown("---")
st.sidebar.subheader(t("ai_layer_header", lang))
api_key = st.sidebar.text_input(
    t("api_key_label", lang), type="password", help=t("api_key_help", lang),
)

st.title(t("highrise_header", lang))
st.caption(t("highrise_caption", lang))
st.caption(t("env_inputs_note", lang))

col_inputs, col_results = st.columns([1, 2])

with col_inputs:
    st.header(t("highrise_env_data_header", lang))
    ground_wind_speed_knots = st.slider(t("highrise_ground_wind_label", lang), 0.0, 60.0, 15.0)
    floor_level = st.slider(t("highrise_floor_level_label", lang), 1, 120, 40)
    crane_load_mass_tons = st.slider(t("highrise_crane_load_label", lang), 0.5, 25.0, 4.0, step=0.5)

# Live calculation via the MAKU risk engine (Mathematical Isolation - no math here)
result = calculate_high_rise_kinetic_risk(ground_wind_speed_knots, floor_level, crane_load_mass_tons)
controls = get_controls(result)

with col_results:
    st.header(t("highrise_realtime_header", lang))

    band = result["risk_band"]
    color = {"LOW": "green", "MODERATE": "orange", "HIGH": "red", "CRITICAL": "red"}[band]
    st.markdown(f"### {t('risk_band_label', lang)}: :{color}[{band}]")

    c1, c2, c3 = st.columns(3)
    c1.metric(t("scaled_wind_label", lang), f"{result['scaled_wind_speed']} kt")
    c2.metric(t("oscillation_index_label", lang), result["oscillation_index"])
    c3.metric(t("risk_level_label", lang), band)

    if result["safety_override"]:
        st.error(t("highrise_critical_alert", lang))
    elif band in ("MODERATE", "HIGH"):
        st.warning(t("highrise_high_alert", lang))
    else:
        st.success(t("highrise_standard_ok", lang))

    st.markdown(f"**{t('primary_hazard_label', lang)}:** {result['primary_hazard']}")

    with st.expander(t("drivers_label", lang)):
        st.json(result["drivers"])

    st.subheader(t("controls_label", lang))
    for c in controls:
        st.markdown(f"- {c}")

    st.subheader(t("briefing_label", lang))
    st.info(generate_narrative(result, controls, api_key, lang))
