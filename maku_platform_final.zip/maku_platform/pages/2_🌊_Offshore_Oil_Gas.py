"""
MAKU - Offshore Oil & Gas (Marine) page
UI only. All calculations come from risk_engine.calculate_marine_humidex_risk
(Mathematical Isolation rule - no formulas live in this file).
"""

import streamlit as st
from risk_engine import calculate_marine_humidex_risk
from ai_advisor import get_controls, generate_narrative
from i18n import t, language_selector

st.set_page_config(page_title="MAKU - Offshore (Marine)", page_icon="🌊", layout="wide")

lang = language_selector(st)

st.sidebar.title(t("app_title", lang))
st.sidebar.caption(t("app_tagline", lang))
st.sidebar.markdown("---")
st.sidebar.subheader(t("ai_layer_header", lang))
api_key = st.sidebar.text_input(
    t("api_key_label", lang), type="password", help=t("api_key_help", lang),
)

st.title(t("offshore_header", lang))
st.caption(t("offshore_caption", lang))
st.caption(t("env_inputs_note", lang))

col_inputs, col_results = st.columns([1, 2])

with col_inputs:
    st.header(t("offshore_env_data_header", lang))
    o_temp_c = st.slider(t("offshore_temp_label", lang), 15.0, 45.0, 33.0)
    o_rh_pct = st.slider(t("offshore_rh_label", lang), 40.0, 100.0, 92.0)
    wind_knots = st.slider(t("offshore_wind_label", lang), 0.0, 50.0, 15.0)

# Live calculation via the MAKU risk engine (Mathematical Isolation - no math here)
result = calculate_marine_humidex_risk(o_temp_c, o_rh_pct, wind_knots)
controls = get_controls(result)

WIND_STATUS_KEYS = {
    "Normal Operations": "wind_status_normal",
    "Restricted - Monitor Closely": "wind_status_restricted",
    "Suspended - Crane/Lifting Danger": "wind_status_suspended",
}

with col_results:
    st.header(t("offshore_realtime_header", lang))

    band = result["risk_band"]
    color = {"Low": "green", "Moderate": "orange", "High": "red", "Extreme": "red"}[band]
    st.markdown(f"### {t('risk_band_label', lang)}: :{color}[{band}]")

    c1, c2, c3 = st.columns(3)
    c1.metric(t("humidex_label", lang), result["humidex"])
    c2.metric(
        t("wind_status_label", lang),
        t(WIND_STATUS_KEYS.get(result["wind_risk_status"], "wind_status_normal"), lang),
    )
    c3.metric(t("risk_level_label", lang), band)

    if result["safety_override"]:
        st.error(t("safety_override", lang))
    elif band in ("Moderate", "High"):
        st.warning(t("offshore_elevated_alert", lang))
    else:
        st.success(t("offshore_standard_ok", lang))

    st.markdown(f"**{t('primary_hazard_label', lang)}:** {result['primary_hazard']}")

    with st.expander(t("drivers_label", lang)):
        st.json(result["drivers"])

    st.subheader(t("controls_label", lang))
    for c in controls:
        st.markdown(f"- {c}")

    st.subheader(t("briefing_label", lang))
    st.info(generate_narrative(result, controls, api_key, lang))
