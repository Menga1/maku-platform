"""
MAKU - Data Center Construction & Commissioning page
UI only. All calculations come from risk_engine.calculate_datacenter_kinetic_risk
(Mathematical Isolation rule - no formulas live in this file).
"""

import streamlit as st
from risk_engine import calculate_datacenter_kinetic_risk
from ai_advisor import get_controls, generate_narrative
from i18n import t, language_selector

st.set_page_config(page_title="MAKU - Data Center", page_icon="🏢", layout="wide")

lang = language_selector(st)

st.sidebar.title(t("app_title", lang))
st.sidebar.caption(t("app_tagline", lang))
st.sidebar.markdown("---")
st.sidebar.subheader(t("ai_layer_header", lang))
api_key = st.sidebar.text_input(
    t("api_key_label", lang), type="password", help=t("api_key_help", lang),
)

st.title(t("datacenter_header", lang))
st.caption(t("datacenter_caption", lang))
st.caption(t("env_inputs_note", lang))

col_inputs, col_results = st.columns([1, 2])

with col_inputs:
    st.header(t("datacenter_env_data_header", lang))
    electrical_load_kw = st.slider(t("datacenter_load_label", lang), 10.0, 2000.0, 400.0, step=10.0)
    hot_aisle_temp = st.slider(t("datacenter_hot_aisle_label", lang), 20.0, 55.0, 34.0)
    ceiling_void_confined = st.checkbox(t("datacenter_confined_label", lang), value=False)
    gas_system_armed = st.checkbox(t("datacenter_gas_armed_label", lang), value=True)

# Live calculation via the MAKU risk engine (Mathematical Isolation - no math here)
result = calculate_datacenter_kinetic_risk(
    electrical_load_kw, hot_aisle_temp, ceiling_void_confined, gas_system_armed,
)
controls = get_controls(result)

with col_results:
    st.header(t("datacenter_realtime_header", lang))

    band = result["risk_band"]
    color = {"LOW": "green", "MODERATE": "orange", "HIGH": "red", "CRITICAL": "red"}[band]
    st.markdown(f"### {t('risk_band_label', lang)}: :{color}[{band}]")

    c1, c2, c3 = st.columns(3)
    c1.metric(t("arc_flash_energy_label", lang), result["arc_flash_energy_cal"])
    c2.metric(t("thermal_differential_label", lang), result["thermal_differential"])
    c3.metric(t("risk_level_label", lang), band)

    if result["safety_override"]:
        st.error(t("datacenter_critical_alert", lang))
    elif band in ("MODERATE", "HIGH"):
        st.warning(t("datacenter_high_alert", lang))
    else:
        st.success(t("datacenter_standard_ok", lang))

    st.markdown(
        f"**{t('confined_clean_agent_label', lang)}:** "
        f"{t('yes', lang) if result['confined_armed_danger'] else t('no', lang)}"
    )
    st.markdown(f"**{t('primary_hazard_label', lang)}:** {result['primary_hazard']}")

    with st.expander(t("drivers_label", lang)):
        st.json(result["drivers"])

    st.subheader(t("controls_label", lang))
    for c in controls:
        st.markdown(f"- {c}")

    st.subheader(t("briefing_label", lang))
    st.info(generate_narrative(result, controls, api_key, lang))
